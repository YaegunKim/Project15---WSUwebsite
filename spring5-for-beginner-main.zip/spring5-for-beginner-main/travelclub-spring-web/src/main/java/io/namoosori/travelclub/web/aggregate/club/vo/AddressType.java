package io.namoosori.travelclub.web.aggregate.club.vo;

public enum AddressType {
	//
	Home, 
	Office
}