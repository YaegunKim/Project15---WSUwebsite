package io.namoosori.travelclub.spring.aggregate.club.vo;

public enum RoleInClub {
	//
	Member, 
	President
}