package io.namoosori.travelclub.spring.aggregate.club.vo;

public enum AddressType {
	//
	Home, 
	Office
}